def converting_raw_mgf_to_dict (raw_mgf_file_route_and_file_name):

    file_route = raw_mgf_file_route_and_file_name [0]
    file_name = raw_mgf_file_route_and_file_name [1]

    raw_mgf_file = open (file_route + file_name, 'r')

    raw_mgf_MS2_spectra_list = {}

    scan_number = ''
    peak_list = []
    spectrum_information = []

    for row in raw_mgf_file:

        if row.split('\t')[0] == 'H':
            continue
        if row.split('\t')[0] == 'S' and scan_number != '':
            spectrum_information.append(['retention_seconds', retention_seconds])
            spectrum_information.append(['ionInjection_time', ionInjection_time])
            spectrum_information.append(['instrument_type', instrument_type])
            peak_list.extend([spectrum_information])                            
            raw_mgf_MS2_spectra_list [scan_number] = peak_list
            peak_list = []
            scan_number = ''
            spectrum_information = []
        if row.split('\t')[0] == 'S':
            
            scan_number = int (row.split('\t')[-2:-1][0])
            continue
        elif 'RetTime' in row:
            retention_seconds = (row.split('\t')[-1:][0]).replace('\n', '').replace('\r', '')
            continue
        elif 'IonInjectionTime' in row:
            ionInjection_time = (row.split('\t')[-1:][0]).replace('\n', '').replace('\r', '')
            continue
        elif 'InstrumentType' in row:
            instrument_type = (row.split('\t')[-1:][0]).replace('\n', '').replace('\r', '')
            continue
        else:
            
            obs_m_to_z = round(float(row.split(' ')[0]), 4)
            obs_inten = round(float(row.split(' ')[1]), 4)
            peak_list.append([obs_m_to_z, obs_inten])

    raw_mgf_file.close()

    output_file = open (file_route + 'raw_mgf_to_dict.txt', 'w')
    output_file.write(str(raw_mgf_MS2_spectra_list))
    output_file.close()

    return raw_mgf_MS2_spectra_list
