def adding_measured_intensity_to_thero_frag_ions (work_path,thero_frag_ions,raw_mgf_dict):
    print ('trying match ions')
    file_path = work_path

    three_plex_all_thero_frag_ions_link_MS1 = {}

    import copy

    three_plex_all_thero_frag_ions = copy.deepcopy(thero_frag_ions)
    three_plex_all_thero_frag_ions_unmodified = copy.deepcopy(thero_frag_ions)
    raw_mgf_MS2_spectra_list = copy.deepcopy(raw_mgf_dict)
    all_MS1_scan_number = []
    for each_scan_num in raw_mgf_MS2_spectra_list:
        all_MS1_scan_number.append (int (each_scan_num))

    for each_scan_number in three_plex_all_thero_frag_ions.keys():
        
        scan_number_on_matching = int (each_scan_number.split(':')[0])
        
        MS1_scan_number_on_matching = all_MS1_scan_number[0]
        closest = 1000
        for each_MS1_scan_numebr in all_MS1_scan_number:
            if abs (each_MS1_scan_numebr - scan_number_on_matching) < closest and (each_MS1_scan_numebr - scan_number_on_matching) <0:
                MS1_scan_number_on_matching = each_MS1_scan_numebr
                closest = abs (each_MS1_scan_numebr - scan_number_on_matching)
        raw_mgf_MS2_spectra_list_on_matching = raw_mgf_MS2_spectra_list [MS1_scan_number_on_matching]
        
        three_plex_all_thero_frag_ions_on_matching = three_plex_all_thero_frag_ions_unmodified [each_scan_number]
        numbers_theo_ions = len (three_plex_all_thero_frag_ions_unmodified [each_scan_number])-1
        numbers_peak_list = len (raw_mgf_MS2_spectra_list [MS1_scan_number_on_matching])-1
            
        for i in range (0,numbers_theo_ions):
            value_theo_ion = three_plex_all_thero_frag_ions_unmodified [each_scan_number][i][2]
            match_peak_number = 0
            
            for j in range (0,numbers_peak_list):
                value_peak_list = raw_mgf_MS2_spectra_list [MS1_scan_number_on_matching][j][0]
                matched_peaks = []
                matched_peak_value = {}
                if (value_peak_list - 0.02) < value_theo_ion and value_theo_ion < (value_peak_list + 0.02):
                    match_peak_number = match_peak_number + 1
                    matched_peak_value[(raw_mgf_MS2_spectra_list [MS1_scan_number_on_matching][j][0])] = (raw_mgf_MS2_spectra_list [MS1_scan_number_on_matching][j][1])
                    matched_peaks.append (raw_mgf_MS2_spectra_list [MS1_scan_number_on_matching][j][0])
                    initi_diff_abs = 2
                    for each_peak in matched_peaks:
                        if abs (each_peak - value_theo_ion) < initi_diff_abs :
                            closest_peak = each_peak
                            initi_diff_abs = abs (each_peak - value_theo_ion)
                    three_plex_all_thero_frag_ions [each_scan_number][i].append (matched_peak_value [closest_peak])  
                            
            if match_peak_number == 0:
                three_plex_all_thero_frag_ions [each_scan_number][i].append ('0')
#########################################################################################
### showing the link between MS2 and MS1
        scan_number_link_ms1_ms2 = each_scan_number + '_MS1_' + str (MS1_scan_number_on_matching)
        three_plex_all_thero_frag_ions_link_MS1 [scan_number_link_ms1_ms2] = three_plex_all_thero_frag_ions [each_scan_number]       
#########################################################################################
        
    output_file = open (file_path + 'Dict_all_fragment_ion_add_matched_intens.txt', 'w')
    output_file.write(str(three_plex_all_thero_frag_ions))
    output_file.close()

    return three_plex_all_thero_frag_ions_link_MS1


