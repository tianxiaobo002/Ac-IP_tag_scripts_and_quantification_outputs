def extract_and_return_uni_pep_list (*file_route_and_file_name):
    print ('preparing list unique peptides ')
    import csv

    import re
    
    space = ''
    unique_peptides = []
    unique_peptides_list = []
    
    for each_protein_peptides_csv_file in file_route_and_file_name:
        file_route = each_protein_peptides_csv_file [0]
        file_name = each_protein_peptides_csv_file [1]
        with open (file_route + file_name) as csvfile:
            reader = csv.DictReader (csvfile)
    
            for row in reader:
                scan_number = row['Scan']
                if scan_number == '':
                    break
                else:
                    peptide = space.join (re.findall('[A-Z]+',str (row['Peptide'])))[1:-1]
                    unique_peptide = row ['Unique']
                    Accession = row ['Protein Accession']
                    Accession_peptide = [Accession,peptide]
                    
                    if Accession_peptide not in unique_peptides and unique_peptide == 'Y':
                        unique_peptides.append (Accession_peptide)
                        unique_peptides_list.append (peptide)

    output_file = open (file_route + 'unique_peptides.txt', 'w')
    for pep in unique_peptides:
        output_file.write(str(pep[0])+' '+str(pep[1])+'\n')
    output_file.close()

    print ('finish unique peptides ')
    return unique_peptides_list
