def keep_the_highest_score_PSM (DB_search_psm_file_route,DB_search_psm_file_names):

    import csv
    import re

    space = ''
    peptide_Pcsore_dict = {}
    peptide_PSM_collection = []
    file_route = DB_search_psm_file_route
    
    for each_DB_search_psm_csv_file in DB_search_psm_file_names:
        file_name = each_DB_search_psm_csv_file
        with open(file_route + file_name) as csvfile:
            reader = csv.DictReader(csvfile)

            for row in reader:
                spectrum_information = []
                scan_number = row['Scan']
                peptide_name = space.join (re.findall('[A-Z]+',str (row['Peptide'])))
                
                if scan_number == '':
                    break
                else:
                    peptide = row['Peptide']
                    p_score = round (float (row['-10lgP']),2)
                    mass = round (float (row['Mass']),4)
                    length = int (row['Length'])
                    ppm = round (float (row['ppm']),1)
                    
                    m_over_z = round (float (row['m/z']),4)
                    charge_states = int (row['Z'])
                    retention_time = round (float (row['RT']),2)
                    area = row['Area']
                    fraction = row['Fraction']
                    
                    Id = row['Id'] 
                    scan_number = int (row['Scan'])
                    from_Chimera = row['from Chimera']
                    Source_File = row['Source File']
                    Accession = row['Accession']
                    
                    PTM = row['PTM']
                    AScore = row['AScore']
                    Found_By = row['Found By']
                    
                    spectrum_information.append (peptide)
                    spectrum_information.append (p_score)
                    spectrum_information.append (mass)
                    spectrum_information.append (length)
                    spectrum_information.append (ppm)
                    
                    spectrum_information.append (m_over_z)
                    spectrum_information.append (charge_states)
                    spectrum_information.append (retention_time)
                    spectrum_information.append (area)
                    spectrum_information.append (fraction)
                    
                    spectrum_information.append (Id)
                    spectrum_information.append (scan_number)
                    spectrum_information.append (from_Chimera)
                    spectrum_information.append (Source_File)
                    spectrum_information.append (Accession)
                    
                    spectrum_information.append (PTM)
                    spectrum_information.append (AScore)
                    spectrum_information.append (Found_By)
                    
                    if peptide_name not in peptide_Pcsore_dict:
                        peptide_Pcsore_dict [peptide_name] = [[p_score,spectrum_information]]
                    else:
                        peptide_Pcsore_dict [peptide_name].append ([p_score,spectrum_information])

    import heapq
    for each_peptide_name in peptide_Pcsore_dict:

        peptide_Pcsore_dict [each_peptide_name] = heapq.nlargest (1,peptide_Pcsore_dict [each_peptide_name])

    import csv
    write_by_rows = [['Peptide','-10lgP','Mass','Length','ppm','m/z','Z','RT','Area',
                      'Fraction','Id','Scan','from Chimera','Source File','Accession','PTM','AScore','Found By']]
    
    for each_peptide_name in peptide_Pcsore_dict.keys():
        write_by_rows.append (peptide_Pcsore_dict [each_peptide_name][0][1])
           
    output_file = open (file_route + 'DB search psm_highest_Pscores.csv', 'w', newline = '')
     
    out_put_csv_file_writing = csv.writer(output_file)
    
    out_put_csv_file_writing.writerows(write_by_rows)
    output_file.close()

DB_search_psm_file_route = 'I:\\DIA HCD cleavable quantification tag\\Manuscript preparation\\GitHub Scripts and quantification ouputs\\XB-005 Ac-IP yeast125-BSA1510 mixed sample_mixed_library\\'

keep_the_highest_score_PSM (DB_search_psm_file_route,['DB search psm.csv'])
